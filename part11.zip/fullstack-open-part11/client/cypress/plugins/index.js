 <reference types="cypress" />


/**
 * @type {Cypress.PluginConfig}
 */
module.exports = () => {
  // `on` is used to hook into various events Cypress emits
  // `config` is the resolved Cypress config
}
